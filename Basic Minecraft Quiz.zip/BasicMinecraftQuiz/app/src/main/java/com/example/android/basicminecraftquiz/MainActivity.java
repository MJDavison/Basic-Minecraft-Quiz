package com.example.android.basicminecraftquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private static final String TAG_LOG = MainActivity.class.getSimpleName();
    TextView textViewQuestionNumber, textViewQuestionString, textViewScore;
    Button choice1, choice2, choice3, choice4;
    int points;
    int questionNumber = 0;
    ArrayList<Integer> usedQuestions = new ArrayList<Integer>();
    Question question = new Question();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        textViewQuestionNumber = findViewById(R.id.textView_questionNumber);
        textViewQuestionString = findViewById(R.id.textView_question);
        textViewScore = findViewById(R.id.textView_score);

        choice1 = findViewById(R.id.btn_option1);
        choice2 = findViewById(R.id.btn_option2);
        choice3 = findViewById(R.id.btn_option3);
        choice4 = findViewById(R.id.btn_option4);

        startGame();
    }
    private void startGame(){
        gameLoop();
    }

    Random rand = new Random();
    boolean gameOver = false;
    boolean waitingOnUserInput = false;
    private void gameLoop(){
        if(questionNumber <=4){
                setupRound();
        }
        /*Intent intent = new Intent(MainActivity.this, QuizOver.class);
        intent.putExtra("score", points);
        startActivity(intent);*/


    }

    private void setupRound(){
            int questionToPick = rand.nextInt(5);
        //int questionToPick = 4;
            if(questionToPick < 4 && !usedQuestions.contains(questionToPick)) {
                usedQuestions.add(questionToPick);
                questionNumber++;
                nextRound(questionToPick);
            }
            else if (questionToPick == 4)
                setupRound();
        }

    private void nextRound(int questionToPick) {
            switch (questionToPick) {
                case 0:
                    question = setQuestionOne();
                    displayQuestion(question);
                    break;
                case 1:
                    question = setQuestionTwo();
                    displayQuestion(question);
                    break;
                case 2:
                    question = setQuestionThree();
                    displayQuestion(question);
                    break;
                case 3:
                    question = setQuestionFour();
                    displayQuestion(question);
                    break;
            }
        }


    public Question setQuestionOne() {
        Question question = new Question(3);
        question.setQuestion("What is a Enderman's weakness?");
        question.setOption1("Sword");
        question.setOption2("Bow and Arrow");
        question.setOption3("Water");
        question.setOption4("Pumpkins");

        return question;
    }

    public Question setQuestionTwo() {
        Question question = new Question(1);
        question.setQuestion("How many colours can you dye sheep?");
        question.setOption1("16");
        question.setOption2("4");
        question.setOption3("64");
        question.setOption4("1");

        return question;
    }

    public Question setQuestionThree() {
        Question question = new Question(3);
        question.setQuestion("What colour are creepers?");
        question.setOption1("Blue");
        question.setOption2("Yellow");
        question.setOption3("Green");
        question.setOption4("Orange");

        return question;
    }

    public Question setQuestionFour() {
        Question question = new Question(4);
        question.setQuestion("How many slices can you eat of a cake?");
        question.setOption1("4");
        question.setOption2("8");
        question.setOption3("5");
        question.setOption4("7");

        return question;
    }

    public void displayQuestion(Question question) {
        textViewQuestionNumber.setText("Question "+Integer.toString(questionNumber));
        textViewQuestionString.setText(question.getQuestion());
        choice1.setText(question.getOption1());
        choice2.setText(question.getOption2());
        choice3.setText(question.getOption3());
        choice4.setText(question.getOption4());
        textViewScore.setText("Score: "+Integer.toString(points));
    }

    public void clickedOptionOne(View view) {
        if (clickedCorrectAnswer(1)){
            points++;
            Log.d(TAG_LOG, "Clicked Option 1");
        }

        gameLoop();

    }

    public void clickedOptionTwo(View view) {
        if (clickedCorrectAnswer(2)){
            points++;
            Log.d(TAG_LOG, "Clicked Option 2");
        }
        gameLoop();

    }

    public void clickedOptionThree(View view) {
        if (clickedCorrectAnswer(3)) {
            points++;
            Log.d(TAG_LOG, "Clicked Option 3");
        }
        gameLoop();

    }

    public void clickedOptionFour(View view) {
        if (clickedCorrectAnswer(4)) {
            points++;
            Log.d(TAG_LOG, "Clicked Option 4");
        }
        gameLoop();

    }

    public boolean clickedCorrectAnswer(int optionNumber) {
        if (questionNumber < 4)
            return optionNumber == question.getCorrectOption();
        else {
            Log.i(TAG_LOG, "Out of Questions");
            Intent intent = new Intent(MainActivity.this, QuizOver.class);
            intent.putExtra("score", points);
            startActivity(intent);
            return false;
        }
    }
}