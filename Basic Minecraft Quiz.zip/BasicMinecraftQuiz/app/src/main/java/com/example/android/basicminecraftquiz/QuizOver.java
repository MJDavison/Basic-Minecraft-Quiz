package com.example.android.basicminecraftquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class QuizOver extends AppCompatActivity {
TextView scoreTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_over);
        scoreTextView = findViewById(R.id.textView_Score);
        Intent intent = getIntent();

        int score = intent.getIntExtra("score", 0);
        scoreTextView.setText(Integer.toString(score));
    }
}